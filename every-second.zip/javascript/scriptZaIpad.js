var counter1 = document.getElementById('ipads-sold');
var quantity1 = 0;
var t1;
    
function counterIphone1() {
    quantity1++;
  	counter1.textContent = quantity1 + " Айпада продадени";
    start1();
}
function start1() {
    t1 = setTimeout(counterIphone1, 768);
}

start1();
// For IPADS _-------------------------------
var counter = document.getElementById('iphones-sold');
var quantity = 0;
var t;
    
function counterIphone() {
    quantity++;
  	counter.textContent = quantity + " Айфона продадени";
    start();
}
function start() {
    t = setTimeout(counterIphone, 144.8);
}

start();
// For mac -----------------------------------
var counter2 = document.getElementById('mac');
var quantity2 = 0;
var t2;
    
function counterIphone2() {
    quantity2++;
  	counter2.textContent = quantity2 + " Мак продадени";
    start2();
}
function start2() {
    t2 = setTimeout(counterIphone2, 2000);
}

start2();
// For Revenue -----------------------------------
var counter3 = document.getElementById('revenue');
var quantity3 = 600;
var t3;
    
function counterIphone3() {
    quantity3+=1000;
  	counter3.textContent = "$" + quantity3 + " оборот";
    start3();
}
function start3() {
    t3 = setTimeout(counterIphone3, 100);
}

start3();
// For Apps -----------------------------------
var counter4 = document.getElementById('app');
var quantity4 = 600;
var t4;
    
function counterIphone4() {
    quantity4+=134;
  	counter4.textContent = quantity4 + " свалени Apps";
    start4();
}
function start4() {
    t4 = setTimeout(counterIphone4, 150);
}

start4();
// For Paid to Devs -----------------------------------
var counter5 = document.getElementById('paid');
var quantity5 = 77;
var t5;
    
function counterIphone5() {
    quantity5+=154;
  	counter5.textContent = "$" + quantity5 + " в заплати";
    start5();
}
function start5() {
    t5 = setTimeout(counterIphone5, 150);
}

start5();