var link = [
 '<a href="apple.html">Apple</a>',
 '<a href="animals.html">Животните</a>',
 '<a href="error404/error.html">Интернет</a>',
 '<a href="error404/error.html">Макдоналдс</a>',
 '<a href="error404/error.html">Месинджър</a>',
 '<a href="error404/error.html">Тялото ни</a>',
 '<a href="error404/error.html">Земята</a>',
 '<a href="error404/error.html">Инстаграм</a>'
 ];
	
var randomItem = link[Math.floor(Math.random()*link.length)];
function gop() 
	{
		document.getElementById('h5').innerHTML = randomItem;
	}
	gop();
var link2 = [
 '<a href="apple.html">Apple</a>',
 '<a href="animals.html">Животните</a>',
 '<a href="error404/error.html">Интернет</a>',
 '<a href="error404/error.html">Макдоналдс</a>',
 '<a href="error404/error.html">Месинджър</a>',
 '<a href="error404/error.html">Тялото ни</a>',
 '<a href="error404/error.html">Земята</a>',
 '<a href="error404/error.html">Инстаграм</a>'
];
var randomItem2 = link2[Math.floor(Math.random()*link2.length)];
	function gop2() 
	{
		document.getElementById('h5-2').innerHTML = randomItem2;
	}
	gop2();