//  hronometar v nachaloto
var h1 = document.getElementById('h2'),
    start = document.getElementById('start'),
    stop = document.getElementById('stop'),
    clear = document.getElementById('clear'),
    seconds = 0, minutes = 0,
    t;

function add() {
    seconds++;
    if (seconds >= 60) {
        seconds = 0;
        minutes++;
        
    }
    
    h1.textContent = "Изминаха " + (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00")+ " минути" + " и " + ( seconds + " секунди");

    timer();
}
function timer() {
    t = setTimeout(add, 999);
}
timer();

