var counter = document.getElementById('iphones-sold');
var quantity = 0;
var t;
    
function counterIphone() {
    quantity++;
  	counter.textContent = quantity + " Айфона продадени";
    start1();
}
function start1() {
    t = setTimeout(counterIphone, 144.8);
}

start1();